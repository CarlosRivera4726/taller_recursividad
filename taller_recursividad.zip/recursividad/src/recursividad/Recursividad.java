package recursividad;

import javax.swing.JOptionPane;

public class Recursividad {

    public static void main(String[] args) {
        //punto1 fact = new punto1();
        //System.out.println("Factorial: " + fact.factorial(Integer.parseInt(JOptionPane.showInputDialog("Ingrese un número: "))));
//
        //punto2 sum = new punto2();
        //System.out.println("Sumatoria: " + sum.sumatoria(Integer.parseInt(JOptionPane.showInputDialog("Ingrese un número: "))));
//
        //punto3 sum2 = new punto3();
        //System.out.printf("Sumatoria: %,3f\n", sum2.sumatoria(Integer.parseInt(JOptionPane.showInputDialog("Ingrese un número: "))));
//
        //punto4 invert = new punto4();
        //System.out.printf("Número invertido: %s\n", invert.invertir(Integer.parseInt(JOptionPane.showInputDialog("Ingrese un número: "))));
//        
        //punto5 sumaDig = new punto5();
        //System.out.printf("Número invertido: %d\n", sumaDig.sumaDigitos(Integer.parseInt(JOptionPane.showInputDialog("Ingrese un número: "))));
//        
        //punto6 sumaDig = new punto6();
        //System.out.printf("Número invertido: %d\n", sumaDig.sumaDigitos(Integer.parseInt(JOptionPane.showInputDialog("Ingrese un número: "))));
//        
        //punto7 pote = new punto7();
        //int base = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la base: "));
        //int pot = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la potencia: "));
        //System.out.println("Base: " + base + "\nExponente: " + pot + "\nPotencia: " + pote.potencia(base, pot));
//
        
        
    }

}
